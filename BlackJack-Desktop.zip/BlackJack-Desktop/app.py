import random
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "blackjack.db"
SUITS = {"C": ("Трефы", "♣"), "D": ("Бубны", "♦"), "H": ("Червы", "♥"), "S": ("Пики", "♠")}
RANKS = [("A", "Туз", 11), ("2", "2", 2), ("3", "3", 3), ("4", "4", 4), ("5", "5", 5), ("6", "6", 6), ("7", "7", 7), ("8", "8", 8), ("9", "9", 9), ("10", "10", 10), ("J", "Валет", 10), ("Q", "Дама", 10), ("K", "Король", 10)]
BG = "#102b25"
PANEL = "#183c32"
GOLD = "#e6bd66"
TEXT = "#f7f1df"


def connect_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


def initialize_db():
    with connect_db() as db:
        db.execute("CREATE TABLE IF NOT EXISTS cards (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, rank TEXT NOT NULL, suit TEXT NOT NULL, value INTEGER NOT NULL CHECK(value BETWEEN 1 AND 21), image TEXT NOT NULL DEFAULT '', is_custom INTEGER NOT NULL DEFAULT 0)")
        db.execute("CREATE TABLE IF NOT EXISTS games (id INTEGER PRIMARY KEY AUTOINCREMENT, player_score INTEGER NOT NULL, dealer_score INTEGER NOT NULL, result TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
        if db.execute("SELECT COUNT(*) FROM cards WHERE is_custom=0").fetchone()[0] == 0:
            for suit, (suit_name, _) in SUITS.items():
                for rank, rank_name, value in RANKS:
                    db.execute("INSERT INTO cards(name,rank,suit,value,image,is_custom) VALUES(?,?,?,?,?,0)", (f"{rank_name} {suit_name.lower()}", rank, suit, value, f"img/{rank}{suit}.png"))


def hand_score(hand):
    total = sum(1 if c["rank"] == "A" else c["value"] for c in hand)
    aces = sum(c["rank"] == "A" for c in hand)
    while total + 10 <= 21 and aces:
        total += 10
        aces -= 1
    return total


class BlackJackApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BlackJack — настольная игра")
        self.geometry("1080x760")
        self.minsize(900, 650)
        self.configure(bg=BG)
        self.player = []
        self.dealer = []
        self.deck = []
        self.game_over = True
        self.images = {}
        self.setup_styles()
        self.build_ui()
        self.refresh_cards()
        self.new_game()

    def setup_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=PANEL, foreground=TEXT, padding=(18, 10), font=("Arial", 11, "bold"))
        style.map("TNotebook.Tab", background=[("selected", GOLD)], foreground=[("selected", BG)])
        style.configure("Treeview", background="#f7f1df", foreground="#17231e", fieldbackground="#f7f1df", rowheight=28, font=("Arial", 10))
        style.configure("Treeview.Heading", background=GOLD, foreground=BG, font=("Arial", 10, "bold"))
        style.configure("TCombobox", padding=5)

    def button(self, parent, text, command, primary=False):
        return tk.Button(parent, text=text, command=command, bg=GOLD if primary else "#285345", fg=BG if primary else TEXT, activebackground="#f1d48e", activeforeground=BG, relief="flat", bd=0, padx=16, pady=9, font=("Arial", 10, "bold"), cursor="hand2")

    def build_ui(self):
        header = tk.Frame(self, bg=BG)
        header.pack(fill="x", padx=24, pady=(18, 10))
        tk.Label(header, text="BLACKJACK", bg=BG, fg=GOLD, font=("Georgia", 25, "bold")).pack(side="left")
        tk.Label(header, text="Классическая карточная игра", bg=BG, fg=TEXT, font=("Arial", 11)).pack(side="left", padx=18, pady=(9, 0))
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        self.game_tab = tk.Frame(self.tabs, bg=BG)
        self.cards_tab = tk.Frame(self.tabs, bg=BG)
        self.history_tab = tk.Frame(self.tabs, bg=BG)
        self.tabs.add(self.game_tab, text="Игра")
        self.tabs.add(self.cards_tab, text="Колода и карты")
        self.tabs.add(self.history_tab, text="История партий")
        self.build_game_tab()
        self.build_cards_tab()
        self.build_history_tab()

    def build_game_tab(self):
        top = tk.Frame(self.game_tab, bg=BG)
        top.pack(fill="x", padx=18, pady=18)
        self.status_label = tk.Label(top, text="Новая партия", bg=BG, fg=GOLD, font=("Arial", 17, "bold"))
        self.status_label.pack(side="left")
        self.score_label = tk.Label(top, text="", bg=BG, fg=TEXT, font=("Arial", 12))
        self.score_label.pack(side="right")
        self.table = tk.Frame(self.game_tab, bg=PANEL, highlightbackground=GOLD, highlightthickness=1)
        self.table.pack(fill="both", expand=True, padx=18, pady=(0, 16))
        self.dealer_label = tk.Label(self.table, text="ДИЛЕР", bg=PANEL, fg=TEXT, font=("Arial", 12, "bold"))
        self.dealer_label.pack(anchor="w", padx=18, pady=(16, 4))
        self.dealer_cards = tk.Frame(self.table, bg=PANEL)
        self.dealer_cards.pack(fill="x", padx=18, pady=(0, 14))
        ttk.Separator(self.table).pack(fill="x", padx=18, pady=6)
        self.player_label = tk.Label(self.table, text="ВАШИ КАРТЫ", bg=PANEL, fg=TEXT, font=("Arial", 12, "bold"))
        self.player_label.pack(anchor="w", padx=18, pady=(12, 4))
        self.player_cards = tk.Frame(self.table, bg=PANEL)
        self.player_cards.pack(fill="x", padx=18, pady=(0, 18))
        controls = tk.Frame(self.game_tab, bg=BG)
        controls.pack(fill="x", padx=18, pady=(0, 16))
        self.button(controls, "Взять карту", self.hit, True).pack(side="left", padx=(0, 8))
        self.button(controls, "Остановиться", self.stand).pack(side="left", padx=8)
        self.button(controls, "Новая партия", self.new_game).pack(side="left", padx=8)
        self.button(controls, "Управление картами", lambda: self.tabs.select(self.cards_tab)).pack(side="right")

    def build_cards_tab(self):
        title = tk.Label(self.cards_tab, text="УПРАВЛЕНИЕ КАРТАМИ", bg=BG, fg=GOLD, font=("Arial", 17, "bold"))
        title.pack(anchor="w", padx=18, pady=(18, 12))
        filters = tk.Frame(self.cards_tab, bg=BG)
        filters.pack(fill="x", padx=18, pady=(0, 10))
        tk.Label(filters, text="Поиск", bg=BG, fg=TEXT).pack(side="left")
        self.search_var = tk.StringVar()
        search = tk.Entry(filters, textvariable=self.search_var, width=24, font=("Arial", 10))
        search.pack(side="left", padx=(8, 16), ipady=5)
        self.search_var.trace_add("write", lambda *_: self.refresh_cards())
        tk.Label(filters, text="Масть", bg=BG, fg=TEXT).pack(side="left")
        self.suit_var = tk.StringVar(value="Все")
        suit_box = ttk.Combobox(filters, textvariable=self.suit_var, values=["Все", "Трефы", "Бубны", "Червы", "Пики"], state="readonly", width=12)
        suit_box.pack(side="left", padx=8)
        suit_box.bind("<<ComboboxSelected>>", lambda _e: self.refresh_cards())
        tk.Label(filters, text="Тип", bg=BG, fg=TEXT).pack(side="left", padx=(8, 0))
        self.kind_var = tk.StringVar(value="Все")
        kind_box = ttk.Combobox(filters, textvariable=self.kind_var, values=["Все", "Стандартные", "Мои карты"], state="readonly", width=14)
        kind_box.pack(side="left", padx=8)
        kind_box.bind("<<ComboboxSelected>>", lambda _e: self.refresh_cards())
        columns = ("id", "name", "rank", "suit", "value", "kind", "image")
        self.card_tree = ttk.Treeview(self.cards_tab, columns=columns, show="headings", selectmode="browse")
        headings = {"id": "ID", "name": "Название", "rank": "Ранг", "suit": "Масть", "value": "Очки", "kind": "Тип", "image": "Изображение"}
        widths = {"id": 50, "name": 220, "rank": 80, "suit": 100, "value": 65, "kind": 110, "image": 220}
        for col in columns:
            self.card_tree.heading(col, text=headings[col])
            self.card_tree.column(col, width=widths[col], anchor="center" if col != "name" else "w")
        self.card_tree.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        actions = tk.Frame(self.cards_tab, bg=BG)
        actions.pack(fill="x", padx=18, pady=(0, 18))
        self.button(actions, "Добавить карту", self.add_card, True).pack(side="left", padx=(0, 8))
        self.button(actions, "Изменить выбранную", self.edit_card).pack(side="left", padx=8)
        self.button(actions, "Удалить выбранную", self.delete_card).pack(side="left", padx=8)
        self.button(actions, "Обновить", self.refresh_cards).pack(side="right")

    def build_history_tab(self):
        tk.Label(self.history_tab, text="ИСТОРИЯ ПАРТИЙ", bg=BG, fg=GOLD, font=("Arial", 17, "bold")).pack(anchor="w", padx=18, pady=(18, 12))
        cols = ("id", "player", "dealer", "result", "date")
        self.history_tree = ttk.Treeview(self.history_tab, columns=cols, show="headings")
        labels = {"id": "№", "player": "Ваш счёт", "dealer": "Счёт дилера", "result": "Результат", "date": "Дата"}
        for col in cols:
            self.history_tree.heading(col, text=labels[col])
            self.history_tree.column(col, width=150, anchor="center")
        self.history_tree.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        self.button(self.history_tab, "Обновить историю", self.refresh_history).pack(anchor="e", padx=18, pady=(0, 18))

    def all_cards(self, custom_filter=None):
        with connect_db() as db:
            if custom_filter is None:
                rows = db.execute("SELECT * FROM cards ORDER BY is_custom DESC, suit, id").fetchall()
            else:
                rows = db.execute("SELECT * FROM cards WHERE is_custom=? ORDER BY suit,id", (custom_filter,)).fetchall()
        return [dict(row) for row in rows]

    def new_game(self):
        cards = self.all_cards(0)
        if len(cards) < 4:
            messagebox.showerror("Ошибка", "В базе должно быть не менее четырёх стандартных карт.")
            return
        self.deck = cards[:]
        random.shuffle(self.deck)
        self.player = [self.deck.pop(), self.deck.pop()]
        self.dealer = [self.deck.pop(), self.deck.pop()]
        self.game_over = False
        self.status_label.config(text="Ваш ход")
        self.render_hands(hide_dealer=True)
        if hand_score(self.player) == 21:
            self.finish_game()

    def draw_card(self, parent, card, hidden=False):
        frame = tk.Frame(parent, bg="#f9f5e8", width=94, height=128, highlightbackground="#d5c99f", highlightthickness=1)
        frame.pack(side="left", padx=(0, 10), pady=4)
        frame.pack_propagate(False)
        if hidden:
            tk.Label(frame, text="♠", bg="#244f43", fg=GOLD, font=("Georgia", 38, "bold")).pack(fill="both", expand=True)
            frame.configure(bg="#244f43")
            return
        path = ROOT / card.get("image", "")
        if path.is_file():
            try:
                if str(path) not in self.images:
                    self.images[str(path)] = tk.PhotoImage(file=str(path))
                image = self.images[str(path)]
                tk.Label(frame, image=image, bg="#f9f5e8").pack(fill="both", expand=True)
                return
            except tk.TclError:
                pass
        symbol = SUITS.get(card["suit"], ("", "♣"))[1]
        color = "#bd3434" if card["suit"] in ("D", "H") else "#17231e"
        tk.Label(frame, text=f"{card['rank']}\n{symbol}", bg="#f9f5e8", fg=color, font=("Georgia", 23, "bold")).pack(fill="both", expand=True)

    def render_hands(self, hide_dealer=False):
        for frame in (self.dealer_cards, self.player_cards):
            for child in frame.winfo_children():
                child.destroy()
        for index, card in enumerate(self.dealer):
            self.draw_card(self.dealer_cards, card, hide_dealer and index == 1)
        for card in self.player:
            self.draw_card(self.player_cards, card)
        dealer_score = "?" if hide_dealer else str(hand_score(self.dealer))
        self.dealer_label.config(text=f"ДИЛЕР  ·  {dealer_score}")
        self.player_label.config(text=f"ВАШИ КАРТЫ  ·  {hand_score(self.player)}")
        self.score_label.config(text=f"Ваш счёт: {hand_score(self.player)}")

    def hit(self):
        if self.game_over:
            return
        if not self.deck:
            self.finish_game()
            return
        self.player.append(self.deck.pop())
        if hand_score(self.player) >= 21:
            self.finish_game()
        else:
            self.render_hands(hide_dealer=True)

    def stand(self):
        if not self.game_over:
            while hand_score(self.dealer) < 17 and self.deck:
                self.dealer.append(self.deck.pop())
            self.finish_game()

    def finish_game(self):
        if self.game_over:
            return
        self.game_over = True
        player_score = hand_score(self.player)
        dealer_score = hand_score(self.dealer)
        if player_score > 21:
            result = "Перебор — дилер выиграл"
        elif dealer_score > 21 or player_score > dealer_score:
            result = "Победа"
        elif player_score < dealer_score:
            result = "Поражение"
        else:
            result = "Ничья"
        self.status_label.config(text=result)
        self.render_hands(hide_dealer=False)
        with connect_db() as db:
            db.execute("INSERT INTO games(player_score,dealer_score,result) VALUES(?,?,?)", (player_score, dealer_score, result))
        self.refresh_history()

    def refresh_cards(self):
        if not hasattr(self, "card_tree"):
            return
        for item in self.card_tree.get_children():
            self.card_tree.delete(item)
        search = self.search_var.get().strip().lower()
        suit_filter = self.suit_var.get()
        kind_filter = self.kind_var.get()
        with connect_db() as db:
            rows = db.execute("SELECT * FROM cards ORDER BY is_custom DESC, suit, id").fetchall()
        for row in rows:
            card = dict(row)
            suit_name = SUITS.get(card["suit"], (card["suit"], ""))[0]
            kind = "Моя карта" if card["is_custom"] else "Стандартная"
            if search and search not in card["name"].lower() and search not in card["rank"].lower() and search not in suit_name.lower():
                continue
            if suit_filter != "Все" and suit_name != suit_filter:
                continue
            if kind_filter == "Стандартные" and card["is_custom"]:
                continue
            if kind_filter == "Мои карты" and not card["is_custom"]:
                continue
            self.card_tree.insert("", "end", values=(card["id"], card["name"], card["rank"], suit_name, card["value"], kind, card["image"]))

    def selected_card(self):
        selection = self.card_tree.selection()
        if not selection:
            messagebox.showinfo("Выбор карты", "Сначала выберите карту в таблице.")
            return None
        values = self.card_tree.item(selection[0], "values")
        with connect_db() as db:
            row = db.execute("SELECT * FROM cards WHERE id=?", (values[0],)).fetchone()
        return dict(row) if row else None

    def card_dialog(self, card=None):
        editing = card is not None
        if editing and not card["is_custom"]:
            messagebox.showwarning("Недоступно", "Стандартные карты нельзя изменять.")
            return
        dialog = tk.Toplevel(self)
        dialog.title("Изменить карту" if editing else "Новая карта")
        dialog.configure(bg=BG)
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        fields = tk.Frame(dialog, bg=BG)
        fields.pack(padx=22, pady=20)
        name_var = tk.StringVar(value=card["name"] if editing else "")
        rank_var = tk.StringVar(value=card["rank"] if editing else "CUSTOM")
        suit_var = tk.StringVar(value=card["suit"] if editing else "C")
        value_var = tk.StringVar(value=str(card["value"]) if editing else "10")
        image_var = tk.StringVar(value=card["image"] if editing else "")
        inputs = [("Название", name_var, "entry"), ("Ранг", rank_var, "entry"), ("Масть", suit_var, "suit"), ("Очки (1–21)", value_var, "entry"), ("Путь к изображению", image_var, "entry")]
        for i, (label, variable, kind) in enumerate(inputs):
            tk.Label(fields, text=label, bg=BG, fg=TEXT, anchor="w").grid(row=i, column=0, sticky="w", padx=(0, 12), pady=7)
            if kind == "suit":
                widget = ttk.Combobox(fields, textvariable=variable, values=list(SUITS.keys()), state="readonly", width=27)
            else:
                widget = tk.Entry(fields, textvariable=variable, width=30)
            widget.grid(row=i, column=1, pady=7, ipady=4)
        tk.Label(fields, text="Например: img/AC.png или оставьте пустым", bg=BG, fg="#b7c8be", font=("Arial", 8)).grid(row=5, column=1, sticky="w")

        def save():
            name = name_var.get().strip()
            rank = rank_var.get().strip() or "CUSTOM"
            suit = suit_var.get().strip().upper()
            image = image_var.get().strip()
            try:
                value = int(value_var.get())
            except ValueError:
                messagebox.showerror("Ошибка", "Очки должны быть числом от 1 до 21.", parent=dialog)
                return
            if not name or suit not in SUITS or not 1 <= value <= 21:
                messagebox.showerror("Ошибка", "Проверьте название, масть и значение карты.", parent=dialog)
                return
            with connect_db() as db:
                if editing:
                    db.execute("UPDATE cards SET name=?,rank=?,suit=?,value=?,image=? WHERE id=? AND is_custom=1", (name, rank, suit, value, image, card["id"]))
                else:
                    db.execute("INSERT INTO cards(name,rank,suit,value,image,is_custom) VALUES(?,?,?,?,?,1)", (name, rank, suit, value, image))
            dialog.destroy()
            self.refresh_cards()

        self.button(dialog, "Сохранить", save, True).pack(pady=(0, 18))
        dialog.update_idletasks()
        dialog.geometry(f"{dialog.winfo_reqwidth()}x{dialog.winfo_reqheight()}+{self.winfo_rootx()+120}+{self.winfo_rooty()+100}")

    def add_card(self):
        self.card_dialog()

    def edit_card(self):
        card = self.selected_card()
        if card:
            self.card_dialog(card)

    def delete_card(self):
        card = self.selected_card()
        if not card:
            return
        if not card["is_custom"]:
            messagebox.showwarning("Недоступно", "Стандартные карты нельзя удалять.")
            return
        if messagebox.askyesno("Удаление", f"Удалить карту «{card['name']}»?"):
            with connect_db() as db:
                db.execute("DELETE FROM cards WHERE id=? AND is_custom=1", (card["id"],))
            self.refresh_cards()

    def refresh_history(self):
        if not hasattr(self, "history_tree"):
            return
        for item in self.history_tree.get_children():
            self.history_tree.delete(item)
        with connect_db() as db:
            rows = db.execute("SELECT id,player_score,dealer_score,result,created_at FROM games ORDER BY id DESC").fetchall()
        for row in rows:
            self.history_tree.insert("", "end", values=tuple(row))


if __name__ == "__main__":
    initialize_db()
    BlackJackApp().mainloop()
